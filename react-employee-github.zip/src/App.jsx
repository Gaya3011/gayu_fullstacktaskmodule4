import EmployeeProfile from "./components/EmployeeProfile";
import EmployeeSalary from "./components/EmployeeSalary";
import EmployeeLogin from "./components/EmployeeLogin";

function App() {
  return (
    <main className="container">
      <h1>Employee Management</h1>

      <EmployeeProfile
        name="Arun"
        employeeId="EMP101"
        role="Software Developer"
        department="IT"
      />

      <EmployeeSalary name="Arun" initialSalary={30000} />

      <EmployeeLogin />
    </main>
  );
}

export default App;
