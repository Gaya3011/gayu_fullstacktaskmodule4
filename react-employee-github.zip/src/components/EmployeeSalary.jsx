import { useState } from "react";

function EmployeeSalary({ name, initialSalary }) {
  const [salary, setSalary] = useState(initialSalary);

  const increaseSalary = () => setSalary((current) => current + 1000);

  const decreaseSalary = () => {
    setSalary((current) => Math.max(0, current - 1000));
  };

  return (
    <section className="card">
      <h2>Employee Salary</h2>
      <p><strong>Employee Name:</strong> {name}</p>
      <p><strong>Basic Salary:</strong> ₹{salary.toLocaleString("en-IN")}</p>

      <button onClick={increaseSalary}>Increase Salary</button>
      <button onClick={decreaseSalary}>Decrease Salary</button>
    </section>
  );
}

export default EmployeeSalary;
