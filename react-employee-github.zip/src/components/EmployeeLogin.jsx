import { useState } from "react";

function EmployeeLogin() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");

  const handleLogin = (event) => {
    event.preventDefault();

    if (!username.trim() || !password.trim()) {
      setMessage("Please enter username and password");
      return;
    }

    setMessage("Login Successful");
  };

  return (
    <section className="card">
      <h2>Employee Login</h2>

      <form onSubmit={handleLogin}>
        <label>
          Username
          <input
            type="text"
            value={username}
            onChange={(event) => setUsername(event.target.value)}
            placeholder="Enter username"
          />
        </label>

        <label>
          Password
          <input
            type="password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            placeholder="Enter password"
          />
        </label>

        <button type="submit">Login</button>
      </form>

      {message && <p className="message">{message}</p>}
    </section>
  );
}

export default EmployeeLogin;
