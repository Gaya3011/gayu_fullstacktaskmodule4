function EmployeeProfile({ name, employeeId, role, department }) {
  return (
    <section className="card">
      <h2>Employee Profile</h2>
      <p><strong>Name:</strong> {name}</p>
      <p><strong>ID:</strong> {employeeId}</p>
      <p><strong>Role:</strong> {role}</p>
      <p><strong>Department:</strong> {department}</p>
    </section>
  );
}

export default EmployeeProfile;
