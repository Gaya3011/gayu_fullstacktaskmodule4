# React Employee Management

A simple React + Vite hands-on project demonstrating:

- Props: Employee Profile
- Props + State: Employee Salary
- State: Employee Login

## Run locally

```bash
npm install
npm run dev
```

Then open the localhost URL shown in the terminal.

## Build

```bash
npm run build
```
